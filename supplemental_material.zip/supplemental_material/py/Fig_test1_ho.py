# Test Case: 1 well and steady flow with homogeneous hydraulic conductivity field  
# and a constant porosity of 0.3

import Isochrone 
m = Isochrone.SteadyFlow('../Test_1/test1',LAYER=0)  
m.ComputeVelocityFieldInterpolator(porosity=0.3)    # constant porosity 
fig,ax = m.CreateFigure()
m.PlotStreamLines() 
m.PlotWells()
times = [60,365,3*365]
linec = ['g','b','r']
lines = dict()
Niso = len(times)
wells = [] 
ISOs = [] 
for i in range(Niso):
    ISO = m.ComputeIsochroneWells(time=times[i],wells=wells,MAXSTEPS=60,DP=5)
    ISOs = ISOs + ISO
for i in range(len(ISOs)) :
    PX , PY = ISOs[i][:2]
    lines[i], = ax.plot(PX,PY,linec[i])
    
m.ExportIsochrones(ISOs,"../txt/test1_ho.txt")
fig.savefig('../pdf/test1_ho.pdf')
m.ExportIsochronesShapes(ISOs,"../shapes/test1_ho")

# line command
# ./Isochrone.py -P -t -b ../Test_1 -p 0.3 -x 0 -y 0 -a 0 -f 0 -i test1 -o test1_ho 60 365 1095

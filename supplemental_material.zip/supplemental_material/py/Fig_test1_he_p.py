# Test Case: 1 well and steady flow with heterogeneous hydraulic conductivity field  
# and a non constant porosity

import Isochrone 
m = Isochrone.SteadyFlow('../Test_2/test1',LAYER=0)  
m.ComputeVelocityFieldInterpolator(porosity="porosity.txt")    # non constant porosity 
fig,ax = m.CreateFigure()
m.PlotStreamLines() 
m.PlotWells()
times = [60,365,3*365]
linec = ['g','b','r']
lines = dict()
Niso = len(times)
wells = [] 
ISOs = [] 
for i in range(Niso):
    ISO = m.ComputeIsochroneWells(time=times[i],wells=wells,MAXSTEPS=60,DP=5)
    ISOs = ISOs + ISO
for i in range(len(ISOs)) :
    PX , PY = ISOs[i][:2]
    lines[i], = ax.plot(PX,PY,linec[i])
    
m.ExportIsochrones(ISOs,"../txt/test1_he_p.txt")
fig.savefig('../pdf/test1_he_p.pdf')
m.ExportIsochronesShapes(ISOs,"../shapes/test1_he_p")

# line command
# ./Isochrone.py -P -t -b /Users/feo/WORK/HYDROGEOLOGY/InitialModels/Example/Test_1 -p 0.3 -x 0 -y 0 -a 0 -f 0 -i test1 -o test1_ho 60 365 1095

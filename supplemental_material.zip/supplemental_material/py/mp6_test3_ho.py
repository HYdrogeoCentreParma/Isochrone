# This script compares results between backward tracking with MODPATH and the results
# from the Isochrones.py for t=365 days and the test case 4 wells placed longitudinal 
# and a steady flow with homogeneous hydraulic conductivity field and a constant porosity of 0.3.
# Using: https://github.com/modflowpy/flopy/blob/develop/examples/Notebooks/flopy3_Modpath_example.ipynb

import sys
import shutil
import os
import glob
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import flopy

# load MODFLOW model 

model_ws = '../Test_1/'
m = flopy.modflow.Modflow.load('test3.nam', model_ws=model_ws)
m.get_package_list()

nrow, ncol, nlay, nper = m.nrow_ncol_nlay_nper
nrow, ncol, nlay, nper

m.dis.steady.array

hdsfile = flopy.utils.HeadFile(model_ws + 'test3.hds')
hdsfile.get_kstpkper()

hds = hdsfile.get_data(kstpkper=(0,0))

hds 

plt.imshow(hds[0, :, :])
plt.colorbar();

mp = flopy.modpath.Modpath(modelname='test3',
                           exe_name='mp6',    
                           modflowmodel=m,
                           model_ws='../Test_1/',
                           dis_file=m.name+'.dis',
                           head_file=m.name+'.hds',
                           budget_file=m.name+'.bud')

mpb = flopy.modpath.ModpathBas(mp, hdry=m.lpf.hdry, laytyp=m.lpf.laytyp, ibound=1, prsity=0.3)

sim = mp.create_mpsim(trackdir='backward', simtype='pathline')

mp.write_input()

mp.run_model(silent=False)

pthobj = flopy.utils.PathlineFile('../Test_1/test3.mppth')
epdobj = flopy.utils.EndpointFile('../Test_1/test3.mpend')
well_epd = epdobj.get_alldata()
well_pathlines = pthobj.get_alldata() # returns a list of recarrays; one per pathline

fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(1, 1, 1, aspect='equal')
modelmap = flopy.plot.ModelMap(model=m, layer=0)
quadmesh = modelmap.plot_ibound()
linecollection = modelmap.plot_grid()
quadmesh = modelmap.plot_bc('WEL', kper=1, plotAll=True)
contour_set = modelmap.contour_array(hds, 
                                     levels=np.arange(np.min(hds),np.max(hds),0.5), colors='b')
plt.clabel(contour_set, inline=1, fontsize=14)

modelmap.plot_pathline(well_pathlines, travel_time='<365',
                       layer='all', colors='red');

# use shapes
import sys
sys.path.append("../pyshp-1.2.11") 
import shapefile
sf = shapefile.Reader("../shapes/test3_ho")
shapes = sf.shapes()
for i in range(4,8) : xy=np.array(shapes[i].points);plt.plot(xy[:,0],xy[:,1]+500)

fig.savefig("../pdf/mp6_test3_ho.pdf")

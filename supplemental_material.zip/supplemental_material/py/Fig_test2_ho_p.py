# Test Case: 4 wells placed perpendicular to a steady flow with homogeneous hydraulic 
# conductivity field and a non constant porosity 

import Isochrone 
m=Isochrone.SteadyFlow('../Test_1/test2',LAYER=0)  
m.ComputeVelocityFieldInterpolator(porosity="porosity.txt")    # non constant porosity 
fig,ax=m.CreateFigure()
m.PlotStreamLines() 
m.PlotWells()
times = [60,365,3*365]
linec = { 60:'g',365:'b',1095:'r'}
lines = dict()
Niso = len(times)
wells = [] 
ISOs = [] 
for i in range(Niso):
    ISO  = m.ComputeIsochroneWells(time=times[i],wells=wells,MAXSTEPS=60,DP=5)
    ISOs = ISOs + ISO
for i in range(len(ISOs)) :
    PX , PY = ISOs[i][:2]
    color = linec[ISOs[i][2]]
    lines[i],=ax.plot(PX,PY,color)

m.ExportIsochrones(ISOs,"../txt/test2_ho_p.txt")
fig.savefig('../pdf/test2_ho_p.pdf')
m.ExportIsochronesShapes(ISOs,"../shapes/test2_ho_p")

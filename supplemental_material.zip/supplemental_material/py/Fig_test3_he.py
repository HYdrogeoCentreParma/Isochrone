# Test Case: 4 wells placed longitudinal to a steady flow with heterogeneous hydraulic 
# conductivity field and a constant porosity of 0.3

import Isochrone 
m=Isochrone.SteadyFlow('../Test_2/test3',LAYER=0)  
m.ComputeVelocityFieldInterpolator(porosity=0.3)    # constant porosity 
fig,ax=m.CreateFigure()
m.PlotStreamLines() 
m.PlotWells()
times = [60,365,3*365]
linec = { 60:'g',365:'b',1095:'r'}
lines = dict()
Niso = len(times)
wells = [] 
ISOs = [] 
for i in range(Niso):
    ISO  = m.ComputeIsochroneWells(time=times[i],wells=wells,MAXSTEPS=60,DP=5)
    ISOs = ISOs + ISO
for i in range(len(ISOs)) :
    PX , PY = ISOs[i][:2]
    color = linec[ISOs[i][2]]
    lines[i],=ax.plot(PX,PY,color)

m.ExportIsochrones(ISOs,"../txt/test3_he.txt")
fig.savefig('../pdf/test3_he.pdf')
m.ExportIsochronesShapes(ISOs,"../shapes/test3_he")

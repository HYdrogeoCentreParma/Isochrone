

 Here there is the Isochrone module that can be used to generate 
 the Isochrone associated to a given well on a single steady flow 
 layer of a model computed using Modflow2005.

 The python can be used as an imported module or as a command line
 script.
